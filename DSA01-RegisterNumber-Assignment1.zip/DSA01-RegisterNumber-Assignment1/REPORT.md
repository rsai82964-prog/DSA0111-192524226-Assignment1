# Assignment 1 Report
## Design, Implement and Validate the Fare Logic of a City Metro Smart-Card System

**Student name:** [Enter full name]  
**Register number:** [Enter register number]  
**GitHub repository:** [Paste live repository URL after publishing]  
**Compiler:** GNU g++ 14.2.0 (Debian 14.2.0-19), C++17  
**Build flags:** `-std=c++17 -Wall -Wextra -Wconversion`

## Scenario and assumptions

The supplied assignment defines Inner, Middle and Outer base fares of Rs 10, Rs 20 and Rs 30. Peak hours are 08:00–09:59 and 17:00–19:59; exactly 10:00 and 20:00 are off-peak. A journey may be accepted only if the post-fare balance is at least Rs 50. Money is stored in integer paise. The original assignment does not specify the exact student/senior concession percentages, so the base implementation does not invent them; this is an item to clarify with the faculty before implementing concessions. Task 12 explicitly adds Airport at Rs 60, a 10% weekend discount that replaces (does not combine with) peak surcharge, and an unlimited monthly pass covering two selected zones.

## Task 1 — Understand the problem and identify objects (4 marks)

| Object | Data | Behaviour / justification |
|---|---|---|
| `SmartCard` | card ID, balance in paise | Checks eligibility and deducts fare atomically; owns the balance invariant. |
| `Passenger` | passenger ID and concession category | Supplies eligibility information for a concession policy; avoids embedding passenger-specific facts in the card. |
| `Journey` | origin/destination or farthest zone, hour, weekend flag | Describes a trip and supplies facts to the fare calculation. |
| `Zone` | one of Inner, Middle, Outer (later Airport) | A closed set of named zone values; prevents unexplained numeric zone codes. |
| `FareTable` | base fare per zone, surcharge/discount rules | Centralizes policy so a fare change is not repeated in several functions. |

A procedural design would use records/variables and free functions such as `calculateFare(zone, hour)` and `canTravel(balance, fare)`. An OOP design places related data and behaviour together. Encapsulation protects the balance; abstraction exposes `canTravel`/`deduct` rather than internal arithmetic; inheritance could model `StudentPassenger` and `SeniorPassenger` from `Passenger` if their data/behaviour genuinely differ; polymorphism could let a `ConcessionPolicy` interface calculate a concession with student and senior implementations. Avoid inheritance if simple data and a policy function are sufficient.

A compact UML class sketch is provided in `UML.md`. Correctness invariants: fare is non-negative; invalid zone/hour is rejected; money arithmetic is integer paise; no deduction occurs unless `balance - fare >= 5000`; a denied trip leaves balance unchanged; peak is `hour >= 8 && hour < 10 || hour >= 17 && hour < 20`; no journey may produce a negative balance. Time per journey and memory per card are O(1) in either procedural or OOP styles. OOP typically localizes a rule change to a class/policy; procedural code can be equally fast but changes may require locating every free function and shared global.

## Task 2 — Tokens, identifiers and constants (3 marks)

Examples: keywords `class`, `enum`, `return`; identifiers `MIN_BALANCE_PAISE`, `fare`; literals/constants `5000`, `20`; operators `+`, `>=`, `&&`; punctuators `{}`, `;`, `()`. `#define` is preprocessor text substitution and has no type or ordinary C++ scope. `const` makes an object non-modifiable; `constexpr` permits compile-time evaluation when its initializer qualifies. `constexpr` is appropriate for fixed fares and percentages. `enum class Zone { Inner, Middle, Outer }` scopes names and prevents implicit conversion to integers, unlike an unscoped enum. Use descriptive `UPPER_SNAKE_CASE` for constants and `lowerCamelCase` for functions/variables. Macro replacement normally adds no storage; a constexpr value often requires no storage after optimization. Runtime cost is not meaningfully different, but macros provide weaker type checking and scope safety.

## Task 3 — Data types and compatibility (4 marks)

| Value | Recommended type | Reason |
|---|---|---|
| Fare/balance in paise | `long long` | Exact integer arithmetic and large totals. |
| Hour | `int` | Small bounded whole number 0–23. |
| Zone | `enum class Zone` | Named, type-safe finite values. |
| Peak/weekend/allowed | `bool` | True/false state. |
| Card identifier | `std::string` | Text identifier. |
| Daily journey count | `long long` | Avoids narrow count limits as volume grows. |
| Collection total | `long long` | 3,000,000 × 3,600 paise = 10,800,000,000 paise, exceeding `INT_MAX`. |
| Fractional measurement only | `double` | Not preferred for money. |

On the tested system: bool 1 byte, char 1, int 4, long long 8, float 4 and double 8. `INT_MAX=2,147,483,647`; `LLONG_MAX=9,223,372,036,854,775,807`. Exact paise avoids binary floating-point representation and accumulation errors. A million additions of 0.10 as `double` produced approximately `100000.00000133288`, while integer paise gave exactly 100000.00 rupees. Addition is O(1) in both representations; each scalar uses 8 bytes on this system. Repeating n additions is O(n).

## Task 4 — Implicit conversions (4 marks)

The pre-run prediction is in `Task04/prediction.txt`; the executed output is in `Task04/outputs/actual_output.txt`. Actual output:

```text
3 3.5
C 68
1 true
s >= u
```

`a/b` is integer division (7/2 = 3), then converts to double when assigned to `c`; the cast in `d` makes the division floating-point. `'A'+2` is integral arithmetic and becomes `C`; printing `ch+1` promotes char to int and prints 68. Integer 5 converts to bool true; default output is 1, and `boolalpha` prints `true`. In `s < u`, signed -1 is converted to unsigned for comparison, so the condition is false. The initial prediction mistakenly wrote 2 instead of 3; the mismatch is documented as a prediction error, not a runtime discrepancy. Use explicit `static_cast`, brace initialization for narrowing-sensitive values, and avoid mixed signed/unsigned comparisons. Runtime and storage remain O(1); explicit conversions make intent clearer and brace initialization catches narrowing at compile time.

## Task 5 — Operators and precedence (4 marks)

Peak check: `(hour >= 8 && hour < 10) || (hour >= 17 && hour < 20)`. Surcharge: `base + base * PEAK_SURCHARGE_PERCENT / 100`. Eligibility: `balance - fare >= MIN_BALANCE_PAISE`. `*`, `/`, `%` bind more tightly than `+`; comparisons bind more tightly than `&&`, which binds more tightly than `||`. Parentheses are recommended for readability. `x++` yields the old value and increments afterwards; `++x` increments first. Avoid `i = i++` because it is confusing and has historically been a source of undefined/unspecified sequencing problems across language versions and contexts; write `i++` or `++i` alone. Integer division truncates toward zero: `-10/3 == -3`, `-10%3 == -1`.

Actual output for Task 5:

```text
11 16
9 6 4
6 4
3 1 -3 -1
18
```

The prediction wrote `9 6 5` for line two, but the actual y is 4 because `++y` changes 3 to 4 before contributing its value. This is a prediction error documented in `Task05/outputs/prediction_vs_actual.md`. A 24-element peak lookup table still gives O(1) checks but uses about 24 bytes for bool values and requires initialization/maintenance; the expression uses O(1) time and constant space.

## Task 6 — Control structures (4 marks)

Pseudocode is in `Task06/pseudocode.txt`. A `switch` is suitable for a small closed set of zones; `if` handles peak and eligibility; the conditional operator is suitable only for short value selection. A counted/range-based `for` loop suits a known trip collection; `while` is suitable when input continues until a sentinel. `continue` can skip invalid input; `break` exits a switch or loop when appropriate. A switch with no matching case and no default executes no case body, so a default/error path is safer for untrusted zone values.

The completed code uses a switch and integer paise. It produced the expected output: fare Rs 10.00, balance Rs 90; fare Rs 36.00, balance Rs 54; third trip denied and balance remains Rs 54. At exactly 10:00 and 20:00 the peak check is false; at exactly 08:00 and 17:00 it is true. Switch and indexed array lookups are O(1). An array makes adding Airport a table extension but requires valid index checks; a switch makes each zone case explicit. The array stores one fare per zone.

## Task 7 — Procedural versus OOP (4 marks)

`Task07/src/task07.cpp` contains both styles. The procedural function receives balance and fare and returns eligibility; caller code must remember to update the balance safely. `SmartCard` hides `balance_` and combines eligibility with `deduct`, so rejected deductions do not mutate state. Both use O(1) time and O(1) memory per card. Making balance public would not improve time or memory, but any code could set it below Rs 50 or negative and bypass the invariant. Changing the minimum balance is localized to one constant in either example, but encapsulation makes enforcement more reliable.

## Task 8 — Safe input/output (4 marks)

`Task08` checks stream extraction, calls `clear()` and `ignore()` on malformed hour input, validates the hour range and rejects a negative balance. The successful test (`9`, `100`) reports peak=true and Rs 100.00; the invalid test (`x`) reports invalid hour input. `setw`, `setfill`, `fixed` and `setprecision` can format currency consistently; integer paise should be formatted by quotient/remainder to avoid conversion to floating-point. Reading one line with `getline` and parsing with `stoi` plus `try/catch` takes O(L) time for line length L and uses O(L) buffer space. `cin >>` is convenient for token input but requires clearing the stream after failure; line parsing can reject trailing garbage more deliberately.

## Task 9 — Implementation and testing (4 marks)

`Task09` runs nine table-driven cases. Actual result: **9/9 fare cases passed**, and the separate negative-recharge validation also passed. Cases include each zone, peak/off-peak, exact 08:00, 10:00, 17:00 and 20:00 boundaries, a trip leaving exactly Rs 50, low balance, and an unknown zone. Invalid zone is rejected rather than treated as a zero-fare valid trip. The assignment also asks for negative recharge and alphabetic hour handling; the interactive Task 8 demonstrates alphabetic input rejection, and the implemented `validRecharge(-100)` check rejects a negative recharge before changing balance. The five-journey hand calculation is recorded in `Task09/outputs/five_journey_total.txt`. Five hand-checkable example journeys at fares Rs 10, Rs 24, Rs 30, Rs 36 and Rs 20 total Rs 120. The test table takes O(t) time for t tests and O(t) space; adding a boundary case is a new row rather than another duplicated code branch.

## Task 10 — Expectations versus execution (4 marks)

For a constant Rs 36 fare, totals match exactly in the tested run:

| Journeys | Total paise | Total rupees | Fits signed 32-bit int? |
|---:|---:|---:|---|
| 20,000 | 72,000,000 | 720,000 | Yes |
| 500,000 | 1,800,000,000 | 18,000,000 | Yes, narrowly below INT_MAX |
| 3,000,000 | 10,800,000,000 | 108,000,000 | No |

A double rupee total for integer-valued Rs 36 fares matches the displayed totals because these values are exactly representable at this scale; this does not prove floating-point is safe for all monetary values. The repeated 0.10 experiment shows accumulation drift. The int total overflows at network scale; `long long` accommodates the tested total; double has wide range but can introduce rounding error. Addition is O(1) and the scalar sizes on this platform are int 4 bytes, long long 8 bytes, double 8 bytes. Compiler warning files are included for each task; no warning is not proof of correctness. `-Wconversion` was added to `-Wall -Wextra` to expose additional conversion issues.

## Task 11 — Final design recommendation (4 marks)

Retain and modify the OOP design: `enum class Zone`, a single `constexpr`/`std::array` fare table, integer paise in `long long`, constants for surcharge and minimum balance, a `Journey` data type, and an encapsulated `SmartCard` with `canTravel` and `deduct`. Keep peak/weekend/concession policies separate from balance enforcement. A fare revision changes the table/constant in one location. Limits: compiled-in fares require rebuild/redeployment; policy combinations and passes need explicit precedence; real production software would also need persistence, transaction safety, audit logging, input validation and concurrency controls. Per-journey time is O(1), and a sequence of n journeys is O(n). A config file makes a fare change possible without recompilation, but adds O(z) startup parsing and O(z) storage for z zones, plus validation and operational risk from malformed configuration.

## Task 12 — Re-evaluate and adapt the design (8 marks)

**Decision: MODIFY the original design.** Keep SmartCard encapsulation and integer-paise money, but replace the three-case fare switch with a four-entry fare table, add a distinct weekend/peak policy with explicit precedence, and add a `Pass` class that records two covered zones. `Zone::Airport` and the fare table add Rs 60. Weekend discount is applied instead of peak surcharge, never both. A covered zone costs zero under the monthly pass. Worked examples: Airport at peak on a weekday costs Rs 60 (not Rs 72); Outer on a weekend peak hour costs Rs 27 (10% discount, no surcharge); Middle on a weekday peak hour costs Rs 24; a covered Inner journey costs Rs 0. The code demonstrates these rules and leaves the card unchanged on denied deductions. In the sample execution, the pass-covered first Airport journey was free, Outer weekend cost 2700 paise, Middle peak cost 2400 paise, and covered Inner was free. The test output is in `Task12/outputs/actual_output.txt`.

Trade-offs: an indexed table is easier to extend to more zones but must guard invalid enum/index values; a switch is explicit but grows with every zone. Pass coverage is O(1) for two chosen zones using a small boolean array. This is a targeted modification rather than a full redesign because the existing encapsulation and integer-paise arithmetic still satisfy the core correctness rules. The sample assumes a pass-covered journey costs zero and that the weekend discount has priority over peak surcharge, exactly as the changed requirement states.

## Complexity summary

| Operation | Time | Extra space |
|---|---:|---:|
| Fare lookup and rule application | O(1) | O(1) |
| Balance eligibility/deduction | O(1) | O(1) per operation |
| Process n journeys | O(n) | O(1) extra beyond input/report storage |
| Run t table-driven tests | O(t) | O(t) for test definitions |
| Parse a line of length L | O(L) | O(L) input buffer |
| Load z fare values from config | O(z) startup | O(z) |

## Build and reproduce

From repository root, for each task run:

```bash
g++ -std=c++17 -Wall -Wextra -Wconversion TaskNN/src/taskNN.cpp -o TaskNN/program
./TaskNN/program
```

Task 8 needs interactive input. Output and compiler diagnostic files are saved under each task's `outputs/` folder. On Windows/MinGW, run the generated `.exe` file instead of `./program`.

## Submission checklist

- [ ] Replace name/register number placeholders.
- [ ] Create the remote repository named `DSA01-<RegisterNumber>-Assignment1`.
- [ ] Push the local Git history and confirm at least one commit per task.
- [ ] Add faculty as collaborator if the repository is private.
- [ ] Put the live GitHub URL on this report and the repository README.
- [ ] Submit repository link and report through Google Classroom.
